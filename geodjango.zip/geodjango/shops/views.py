from django.shortcuts import render
from .models import Shop2

def home(request):
    all_Shops = Shop2.objects.all()
    context = {'all_Shops': all_Shops}
    return render(request, 'shops/home.html', context)
