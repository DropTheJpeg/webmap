from django.contrib.gis import admin
from django.contrib.gis.admin import OSMGeoAdmin
from world.models import WorldBorder
from shops.models import Shop

@admin.register(Shop)
class ShopAdmin(OSMGeoAdmin):
    list_display = ('name', 'location')

admin.site.register(WorldBorder, admin.OSMGeoAdmin)
